# Assignment 1

 You can find all necessary instructions in **assignment_1.pdf**.

 We provide to you simple unit tests that can check your implementation. However be aware that even if all tests are passed it still doesn't mean that your implementation is correct. You can find tests in **unittests.py**. 
